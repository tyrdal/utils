"""Jedi Language Server."""

from importlib.metadata import version

__version__ = version("jedi-language-server")
